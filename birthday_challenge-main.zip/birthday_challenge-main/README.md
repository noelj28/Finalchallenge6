# birthday_challenge
The birthday-matching problem readily lends itself to Monte Carlo simulation..
